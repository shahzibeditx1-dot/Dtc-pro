# DTC PRO - APK banane ke steps (GitHub)

1. github.com par naya repository banayen (misal: dtc-pro).
2. Is zip ki saari files repository mein upload karein (Add file > Upload files).
   - Agar `.github` folder upload na ho (phone par aksar nahi hota): Add file > Create new file,
     naam mein `.github/workflows/build.yml` likhein aur is zip wali `build.yml` ka text paste kar dein.
3. Commit karein (main branch par). Actions tab mein "Build APK" khud chalna shuru ho jayega (5-8 minute).
4. Complete hone par us run ke andar Artifacts mein `DTC-PRO-APK` download karein, andar `DTC-PRO.apk` hai.
5. Public download link ke liye: Releases > Create a new release > tag `v1.0` banayen > Publish.
   Kuch minute baad `DTC-PRO.apk` release mein khud lag jayegi.
6. Phone mein APK install karein (Unknown sources allow karein), app kholen, "Open Control Panel" dabayen,
   "Display over other apps" permission dein, wapas aa kar dobara dabayen. Phir app minimize karein.

Awaz: `app/src/main/res/raw/voice.mp3` (app khulte hi aik baar chalti hai).
Links: `app/src/main/assets/index.html` mein.
