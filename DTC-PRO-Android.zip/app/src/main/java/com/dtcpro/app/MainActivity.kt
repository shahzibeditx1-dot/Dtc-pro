package com.dtcpro.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var player: MediaPlayer? = null

    inner class Bridge {
        @JavascriptInterface
        fun openPanel() {
            runOnUiThread { startPanel() }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = Color.parseColor("#0A0103")
        window.statusBarColor = bg
        window.navigationBarColor = bg
        web = WebView(this)
        web.setBackgroundColor(bg)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.textZoom = 100
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "http" || u.scheme == "https") {
                    try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) { }
                    return true
                }
                return false
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        if (savedInstanceState == null) playVoice()
    }

    private fun playVoice() {
        try {
            player = MediaPlayer.create(this, R.raw.voice)
            player?.isLooping = false
            player?.start()
        } catch (e: Exception) { }
    }

    private fun startPanel() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Pehle 'Display over other apps' ki permission on karein, phir wapas aa kar dobara dabayein", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, FloatingService::class.java))
        Toast.makeText(this, "Floating icon on ho gaya! Ab app minimize karein.", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        web.destroy()
        super.onDestroy()
    }
}
