package com.dtcpro.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var icon: WebView
    private lateinit var panel: WebView
    private lateinit var iconLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams
    private var iconOn = false
    private var panelOn = false
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    inner class Bridge {
        @JavascriptInterface
        fun hide() {
            ui.post { showIcon() }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startFg()
        icon = makeWeb("icon.html")
        panel = makeWeb("panel.html")
        panel.addJavascriptInterface(Bridge(), "Android")
        iconLp = lp(dp(66), dp(66))
        iconLp.x = dp(12)
        iconLp.y = dp(160)
        panelLp = lp(dp(212), dp(312))
        setupDrag()
        showIcon()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWeb(file: String): WebView {
        val w = WebView(applicationContext)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.settings.javaScriptEnabled = true
        w.settings.textZoom = 100
        w.isVerticalScrollBarEnabled = false
        w.isHorizontalScrollBarEnabled = false
        w.overScrollMode = WebView.OVER_SCROLL_NEVER
        w.loadUrl("file:///android_asset/$file")
        return w
    }

    private fun lp(w: Int, h: Int): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        return p
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupDrag() {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        icon.setOnTouchListener { _, e ->
            val dm = resources.displayMetrics
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = iconLp.x; oy = iconLp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (Math.abs(dx) + Math.abs(dy) > dp(6)) moved = true
                    if (moved) {
                        iconLp.x = (ox + dx).toInt().coerceIn(0, dm.widthPixels - iconLp.width)
                        iconLp.y = (oy + dy).toInt().coerceIn(0, dm.heightPixels - iconLp.height)
                        wm.updateViewLayout(icon, iconLp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) showPanel()
            }
            true
        }
    }

    private fun showPanel() {
        if (iconOn) { wm.removeView(icon); iconOn = false }
        val dm = resources.displayMetrics
        panelLp.x = (dm.widthPixels - panelLp.width) / 2
        panelLp.y = iconLp.y.coerceIn(0, dm.heightPixels - panelLp.height)
        if (!panelOn) { wm.addView(panel, panelLp); panelOn = true }
    }

    private fun showIcon() {
        if (panelOn) { wm.removeView(panel); panelOn = false }
        if (!iconOn) { wm.addView(icon, iconLp); iconOn = true }
    }

    private fun startFg() {
        val ch = "dtc_float"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "DTC PRO", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, FloatingService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch)
            .setContentTitle("DTC PRO")
            .setContentText("Floating icon chal raha hai")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentIntent(open)
            .addAction(0, "Band karein", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        try { if (iconOn) wm.removeView(icon) } catch (e: Exception) { }
        try { if (panelOn) wm.removeView(panel) } catch (e: Exception) { }
        icon.destroy()
        panel.destroy()
        super.onDestroy()
    }
}
